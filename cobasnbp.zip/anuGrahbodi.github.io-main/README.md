# SNBP/ UTBK-SNBT GENERATOR

Generator Pengumuman SNBP di https://anugrahbodi.github.io/

Generator Pengumuman UTBK-SNBT di https://anugrahbodi.github.io/snbt-generator
